# MAGIC QGIS Workshop
### January 8, 2021


Materials for MAGIC's January 2021 QGIS workshop ...
